library(Ball)
library(R.matlab)
Xk = readMat("dataset.mat")
data = Xk$X
p = ncol(data)
CC = matrix(rep(0,p*p),p,p)
for (i in (1:(p-1))){
  for (j in ((i+1):p)){
    CC[i,j] = bcov.test(x=data[,i],y=data[,j])$p.value
  }
}
writeMat("pvalMatrix.mat",pvalMatrix=CC)

