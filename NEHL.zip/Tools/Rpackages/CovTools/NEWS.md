# News for Package CovTools
### Changes in version 0.5.3
  * Fix an error in `CovEst.2010OAS`.
  * Change maintainer's email.
  
### Changes in version 0.5.2
  * Function list is moved to README file.
  * Following functions are added,
    - `CovEst.2003LW`, `CovEst.2010OAS`, `CovEst.2010RBLW`.
    
### Changes in version 0.5.1
  * Functions for hypothesis tests are separated for clarity.
  * Initialize the following documentation:
    - NEWS for keeping record of updates.
    - README to briefly introduce the method.
