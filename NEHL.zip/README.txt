INTRODUCTION
This package includes some basic codes and functions for learning causal structures from the simulation data and real data, 
as well as implementations of the NEHL algorithm. The package was created in MATLAB R2016a and R 4.0.5.


CONTENTS
-DAG:
Contains all the data and generation methods needed in the experiment:
--(...)Generation(...).m: Generates the Euclidean data and non-Euclidean data in the paper. 
--2019-01-29#2019-02-05.mat: The real data of the power plant in the paper，containing monitoring data of 10,000 time
 nodes at 40 measurement sensors.
--example_... .mat: Examples of generated simulation data (250 samples of the alarm network).
--.csv file: The training data and test data of power plant data which are processed by dataprocess.m in the Tools package.

-Figures:
Saves the experimental results involved in the paper

-Tools
Contains the codes and packages support needed in the running time which are the core part of NEHL algorithm implementation.
--Rpackages: Contains  the R package supports.
--(bcovTest,testfd,testspd).R files: The permutation test processes required by the bcov-Pruned algorithm in the variable selection stage.
--DAGsearch(2,3).m	: The dag search algorithm used in the second stage of NEHL algorithm.

-Prediction
We provide two implementations of data prediction corresponding to the application part of the paper:
--method1: Based on the tensorflow in the python environment. Run the main.py to predict the power plant data in last 2000
time nodes. (Need to configure and install the used packages in the python environment)
--method2: Based on the matlab environment. Run the Run_LSTM to analyse the prediction results.

-RunNEHL_(...).m
The NEHL algorithm running processes on the generated Euclidean data and non-Euclidean data.

-RunRealdata.m
The NEHL algorithm running processes on the 2019-01-29#2019-02-05.mat。

INSTRUCTION
When using this package, you only need to add NEHL and its subfolders to the running path.