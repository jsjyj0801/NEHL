clc;clear;close all;
load('./Data/2019-01-29#2019-02-05.mat');
% Generate the functional data set
X =X(1:8000,:);
data = [];
for j=1:100
    count = 80*(j-1)+1;
    for k = 1:40
        data{k,1}(j,:) = X(count:(count+79),k)';
    end
end
X=data;
save('inputFD.mat','X');
% Learn causal structure
!R CMD BATCH  ./Tools/testfd.R
pvalMatrix2 = load('pvalMatrix2.mat');
pvalMatrix = pvalMatrix2.pvalMatrix2;
k1=0.05;
[SK]=comparePval(pvalMatrix,k1);
rand('state',0);
randn('state',0);
nEvals=2500;
penalty = log(100)/2;
DAG_real= DAGsearch2(X,nEvals,0,penalty,SK);
save('./Data/DAG_real.mat','DAG_real');